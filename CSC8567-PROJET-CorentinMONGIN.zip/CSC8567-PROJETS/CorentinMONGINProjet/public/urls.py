from django.urls import path
from . import views
from .views import ajouter_personne_view


urlpatterns = [
    path('', views.home_view, name='home'),
    path('logements/', views.logements_view, name='logements'),
    path('voitures/', views.voitures_view, name='voitures'),
    path('ajouter-personne/', views.ajouter_personne_view, name='ajouter_personne'),
    path('personnes/', views.liste_personnes_view, name='liste_personnes'),
    path('effacer_personne/<int:personne_id>/', views.effacer_personne_view, name='effacer_personne'),
    path('effacer_tout/', views.effacer_tout_view, name='effacer_tout'),
    path('logements/create/', views.create_logement_view, name='create_logement'),
    path('voitures/create/', views.create_voiture_view, name='create_voiture'),
]

