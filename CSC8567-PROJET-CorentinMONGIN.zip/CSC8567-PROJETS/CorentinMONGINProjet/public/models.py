from django.db import models

class Personne(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    age = models.IntegerField()

    def __str__(self):
        return f"{self.prenom} {self.nom}, {self.age} ans"

    class Meta:
        app_label = 'public'

class Voiture(models.Model):
    nom = models.CharField(max_length=100)
    personnes = models.ManyToManyField(Personne, related_name='voitures', blank=True)

    def __str__(self):
        return self.nom

    class Meta:
        app_label = 'public'

class Logement(models.Model):
    adresse = models.CharField(max_length=255)
    personnes = models.ManyToManyField(Personne, related_name='logements', blank=True)

    def __str__(self):
        return self.nom

    class Meta:
        app_label = 'public'

