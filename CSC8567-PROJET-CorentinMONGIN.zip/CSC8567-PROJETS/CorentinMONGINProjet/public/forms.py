from django import forms
from .models import Logement, Personne, Voiture

class PersonneForm(forms.ModelForm):
    class Meta:
        model = Personne
        fields = ['nom', 'prenom', 'age']

class LogementForm(forms.ModelForm):
    personnes = forms.ModelMultipleChoiceField(
        queryset=Personne.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )

    class Meta:
        model = Logement
        fields = ['adresse', 'personnes']

class VoitureForm(forms.ModelForm):
    personnes = forms.ModelMultipleChoiceField(
        queryset=Personne.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )

    class Meta:
        model = Voiture
        fields = ['nom', 'personnes']