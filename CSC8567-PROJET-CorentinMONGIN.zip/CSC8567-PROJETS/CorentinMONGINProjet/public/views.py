from django.shortcuts import render, redirect
from django.db.models import Count
from .forms import PersonneForm
from .models import Personne
from .models import Voiture, Logement
from .forms import LogementForm, VoitureForm




def home_view(request):
    return render(request, 'public/home.html')

def logements_view(request):
    logements = Logement.objects.all()
    return render(request, 'public/logements.html', {'logements': logements})


def voitures_view(request):
    voitures = Voiture.objects.all()
    return render(request, 'public/voitures.html', {'voitures': voitures})


def ajouter_personne_view(request):
    if request.method == "POST":
        form = PersonneForm(request.POST)
        if form.is_valid():
            personne = form.save()

            # Ajouter la personne dans une voiture qui a moins de 5 personnes
            voiture = Voiture.objects.annotate(num_personnes=Count('personnes')).filter(num_personnes__lt=5).first()
            if voiture:
                voiture.personnes.add(personne)

            # Ajouter la personne dans un logement qui a moins de 5 personnes
            logement = Logement.objects.annotate(num_personnes=Count('personnes')).filter(num_personnes__lt=5).first()
            if logement:
                logement.personnes.add(personne)

            return redirect('liste_personnes')
    else:
        form = PersonneForm()
    return render(request, 'public/ajouter_personne.html', {'form': form})


def liste_personnes_view(request):
    personnes = Personne.objects.all()
    return render(request, 'public/liste_personnes.html', {'personnes': personnes})   

def effacer_personne_view(request, personne_id):
    if request.method == 'POST':
        personne = Personne.objects.get(id=personne_id)
        personne.delete()
    return redirect('liste_personnes')

def effacer_tout_view(request):
    if request.method == 'POST':
        Personne.objects.all().delete()
    return redirect('liste_personnes')

def create_logement_view(request):
    if request.method == 'POST':
        form = LogementForm(request.POST)
        if form.is_valid():
            form.save()  # Sauvegarde le logement et les relations avec les personnes
            return redirect('logements')  # Redirige vers la page des logements
    else:
        form = LogementForm()

    return render(request, 'public/create_logement.html', {'form': form})

def create_voiture_view(request):
    if request.method == 'POST':
        form = VoitureForm(request.POST)
        if form.is_valid():
            form.save()  # Sauvegarde la voiture et les relations avec les personnes
            return redirect('voitures')  # Redirige vers la page des voitures
    else:
        form = VoitureForm()

    return render(request, 'public/create_voiture.html', {'form': form})