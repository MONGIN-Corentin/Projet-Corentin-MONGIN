from django.http import JsonResponse
from django.views import View
from public.models import Personne
from django.shortcuts import get_object_or_404

class PersonneList(View):
    def get(self, request):
        personnes = Personne.objects.all().values()
        return JsonResponse(list(personnes), safe=False)

    def post(self, request):
        # Vous devrez traiter le JSON reçu dans le corps de la requête ici
        # Exemple simple : supposer que les données sont envoyées via request.POST
        data = request.POST
        personne = Personne.objects.create(
            nom=data.get('nom'),
            prenom=data.get('prenom'),
            age=data.get('age'),
            email=data.get('email')
        )
        return JsonResponse({
            'id': personne.id,
            'nom': personne.nom,
            'prenom': personne.prenom,
            'age': personne.age,
            'email': personne.email,
        })

class PersonneDetail(View):
    def get(self, request, pk):
        personne = get_object_or_404(Personne, pk=pk)
        data = {
            'id': personne.id,
            'nom': personne.nom,
            'prenom': personne.prenom,
            'age': personne.age,
            'email': personne.email,
        }
        return JsonResponse(data)

    def put(self, request, pk):
        # Cette partie suppose que les données sont envoyées sous forme de JSON
        data = request.POST
        personne = get_object_or_404(Personne, pk=pk)
        personne.nom = data.get('nom', personne.nom)
        personne.prenom = data.get('prenom', personne.prenom)
        personne.age = data.get('age', personne.age)
        personne.email = data.get('email', personne.email)
        personne.save()
        return JsonResponse({
            'id': personne.id,
            'nom': personne.nom,
            'prenom': personne.prenom,
            'age': personne.age,
            'email': personne.email,
        })

    def delete(self, request, pk):
        personne = get_object_or_404(Personne, pk=pk)
        personne.delete()
        return JsonResponse({'message': 'Personne supprimée avec succès'})
