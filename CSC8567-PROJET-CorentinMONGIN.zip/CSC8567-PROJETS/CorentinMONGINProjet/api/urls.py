from django.urls import path
from .views import PersonneList, PersonneDetail

urlpatterns = [
    path('personnes/', PersonneList.as_view(), name='personne-list'),
    path('personnes/<int:pk>/', PersonneDetail.as_view(), name='personne-detail'),
]
