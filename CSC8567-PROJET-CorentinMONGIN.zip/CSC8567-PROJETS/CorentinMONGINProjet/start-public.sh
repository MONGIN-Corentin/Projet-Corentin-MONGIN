#!/bin/bash

python ./CorentinMONGINProjet/manage.py makemigrations #Regarde les migrations
python ./CorentinMONGINProjet/manage.py migrate  # Appliquer les migrations
python ./CorentinMONGINProjet/manage.py runserver 0.0.0.0:8000 --settings=CorentinMONGINProjet.settings.public
