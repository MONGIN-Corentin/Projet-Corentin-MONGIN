from .base import *

INSTALLED_APPS += [
    'api',
]

ROOT_URLCONF='CorentinMONGINProjet.urls-api'