from .base import *

INSTALLED_APPS += [
    'public',
]

ROOT_URLCONF='CorentinMONGINProjet.urls-public'