Voici les chemins de mon site : 

http://127.0.0.1/public/

http://127.0.0.1/public/logements/

http://127.0.0.1/public/voitures/

http://127.0.0.1/public/ajouter-personne/

http://127.0.0.1/public/personnes/

http://127.0.0.1/api/personnes/

Voici les réponses aux questions : 

Partie 1 Django : 

1. 

Suite de requêtes et exécutions pour afficher une page index.html à l'URL via une application publique sans contexte de données :
Lorsque l'URL est appelée pour afficher la page index.html, les étapes suivantes sont réalisées :

urls.py :

Le fichier urls.py de l’application publique dans le répertoire public/urls.py associe l'URL à une vue view.

views.py :

Le fichier views.py dans public/views.py contient une fonction appelée index qui rend un template HTML sans contexte de données.

Template index.html :

Le fichier index.html est situé dans le répertoire public/templates/public/index.html. Django s'attend à trouver les templates dans un sous-répertoire appelé templates à l'intérieur de l'application.
L'arborescence des fichiers impliqués dans cette exécution est la suivante :

Mon projet/
├── manage.py
├── Mon projet/
│   ├── settings.py
│   ├── urls.py
├── public/
│   ├── migrations/
│   ├── templates/
│   │   └── public/
│   │       └── index.html
│   ├── views.py
│   └── urls.py

2. 

Configuration de la base de données :
La configuration de la base de données pour un projet Django se fait dans le fichier settings.py, situé dans le répertoire principal du projet, par exemple Mon projet/settings.py.

3.

Dans un projet Django, le fichier principal utilisé pour les configurations est le fichier settings.py. Il contient des informations importantes comme la configuration de la base de données, les applications à charger, les templates, etc. Cependant, si on souhaite utiliser différents fichiers de paramètres par exemple avec Docker, il faut créer plusieurs fichiers de paramètres en fonction des besoins spécifiques. Voici les rôles de chaque fichier :

- settings.py : C'est le fichier de paramètres commun par défaut qui centralise toutes les configurations générales du projet. Il regroupe les paramètres partagés comme ceux liés aux bases de données, aux applications à charger, aux templates, etc. Ce fichier est le point de départ pour configurer Django.

- settings_api.py : Ce fichier est dédié aux configurations spécifiques de l'API. Il peut inclure des paramètres comme ceux nécessaires pour gérer les requêtes backend, des configurations pour rest_framework, ou des paramètres liés aux endpoints de l'API. En créant un fichier de paramètres distinct pour l'API, on peut mieux séparer les préoccupations backend du reste du projet.

- settings_front.py : Ce fichier est dédié à la partie front-end du projet. Il gère les configurations spécifiques à l'affichage des templates et à la gestion des applications liées à l'interface utilisateur. Cela permet de séparer les configurations front-end des autres parties du projet pour un meilleur contrôle et une meilleure maintenance.

Lorsque nous travaillons avec plusieurs fichiers de paramètres, il est courant d'utiliser une base commune par exemple settings.py pour les configurations partagées, et de créer des fichiers spécifiques comme settings_api.py et settings_front.py pour les configurations propres à chaque partie du projet. Cela permet une meilleure organisation et une plus grande flexibilité.

4. 

python manage.py makemigrations :

Cette commande génère des fichiers de migration dans le répertoire migrations de chaque application exemple : public/migrations/.
Elle crée des fichiers de migration pour traduire les modifications du modèle Python en actions que la base de données pourra comprendre mais aussi ajouter, modifier ou supprimer des tables ou des colonnes.

python manage.py migrate :

Cette commande applique les migrations à la base de données. Cela crée ou modifie les tables de la base de données selon les migrations générées.
Les fichiers impliqués sont les fichiers de migration créés par makemigrations et les tables de la base de données.

Les fichiers utilisés pendant ces exécutions sont :

Les fichiers de migration situés dans le répertoire migrations de chaque application.
Le fichier de base de données configuré dans settings.py.


Partie 2 Docker :

1.

FROM : Définit l'image de base à utiliser comme FROM python:3.9.
RUN : Exécute des commandes pendant la construction de l'image.
WORKDIR : Définit le répertoire de travail.
EXPOSE : Indique le port à exposer.
CMD : Spécifie la commande à exécuter au démarrage du conteneur.

2.

ports: "80:80" :

Lie le port 80 de l'hôte au port 80 du conteneur, permettant d'accéder au service via le port 80 de l'hôte.

build: :

Définit le répertoire de contexte pour la construction de l'image ici c'est le répertoire courant.

dockerfile: Dockerfile.api : Spécifie le fichier Dockerfile à utiliser ici c'est Dockerfile.api.

depends_on: :

Indique que le service actuel dépend de la disponibilité des services web et api. Docker commencera à démarrer ces services avant celui-ci.

environment: :

Définit des variables d'environnement pour le conteneur en utilisant les valeurs provenant d'un fichier .env exemple comme POSTGRES_DB, POSTGRES_USER, POSTGRES_PASSWORD).

3.

Une méthode pour définir des variables d'environnement dans un conteneur est d'utiliser la section environment: dans le fichier docker-compose.yml, ou via l'option -e lors du lancement d'un conteneur avec docker run.

4.

Pour que le conteneur Nginx puisse adresser le serveur web dans le conteneur web sans utiliser d'adresses IP, on peux utiliser le nom de service ou de conteneur fourni par Docker dans le même réseau.

Dans le fichier docker-compose.yml, si les deux conteneurs font partie du même réseau Docker, on peux configurer Nginx pour accéder à web via son nom de conteneur ou de service. Par exemple, dans la configuration de Nginx qui est le fichier nginx.conf, on utilisera :

proxy_pass http://web:8000;

Le nom web est résolu automatiquement par Docker grâce à son DNS interne. Cela permet à Nginx de communiquer avec le conteneur Django sans avoir besoin d'adresses IP.
